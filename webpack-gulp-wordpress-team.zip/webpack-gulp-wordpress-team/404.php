<?php

get_header();

?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

            <section>
                <p>
                    <?php esc_attr_e('Error 404, Ooops ! Cette page n’existe pas !','textdomaintomodify'); ?>
                </p>
            </section>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
