var devTask = require('./dev');

/**
 * We are just going to use the
 * dev mode task because they
 * are the same
 *
 * @type {Function}
 */
module.exports = devTask;
